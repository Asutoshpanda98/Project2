package com.cg.iter.authenticationservice.controller;


import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/app/applicant")
public class ApplicantController {
	

	
	
	@ApiOperation(
			value = "Validate the applicant",
			notes = "If the user is applicant then only we will get a string response",
			response = String.class
			)
	@PostMapping("/validate")
	@PreAuthorize("hasRole('APPLICANT'")
	public String isApplicant() {
		
		return "authenticated applicant";
	}
	
	 
	
	

}
