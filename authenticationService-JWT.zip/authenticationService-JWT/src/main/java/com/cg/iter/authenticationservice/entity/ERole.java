package com.cg.iter.authenticationservice.entity;

public enum ERole {
	ROLE_APPLICANT,
    ROLE_MAC,
    ROLE_ADMIN,
}
