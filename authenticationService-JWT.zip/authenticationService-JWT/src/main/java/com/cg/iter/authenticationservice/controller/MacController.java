package com.cg.iter.authenticationservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/app/mac")
public class MacController {
	
	
	
	@ApiOperation(
			value = "Validate the mac user",
			notes = "If the user is mac then only we will get a string response",
			response = String.class
			)
	@PostMapping("/validate")
	@PreAuthorize("hasRole('MAC')")
	public String isMac() {
		return "authenticated mac user";
	}
	
	  
	

}
